import type { NextConfig } from "next";

/**
 * Drei Ziele, eine Konfiguration:
 *
 * - **Cloudflare Workers / Vercel (Standard):** voller Next.js-Server. Nur so
 *   ist das Kontaktformular serverseitig (Route Handler /api/kontakt).
 *   Cloudflare-Build: `npm run cf:build`, Deploy: `npm run cf:deploy`.
 * - **Cloudflare Pages (statisch):** `STATIC_EXPORT=true npm run build`
 *   erzeugt ./out ohne basePath. Dort gibt es keine Serverfunktion – das
 *   Formular erkennt das zur Laufzeit und weicht auf E-Mail aus.
 * - **GitHub Pages:** `GITHUB_PAGES=true` erzeugt denselben Export, zusätzlich
 *   unter dem Unterpfad /Omega-Phone.
 */
const isGitHubPages = process.env.GITHUB_PAGES === "true";
const isStaticExport = isGitHubPages || process.env.STATIC_EXPORT === "true";
const basePath = isGitHubPages ? "/Omega-Phone" : "";

const nextConfig: NextConfig = {
  poweredByHeader: false,
  reactStrictMode: true,
  ...(isStaticExport ? { output: "export" as const } : {}),
  basePath,
  // Das Projekt nutzt kein next/image; unoptimized hält den Build auf jeder
  // Plattform gleich – auch auf Workern ohne Bild-Optimizer.
  images: { unoptimized: true },
  env: {
    // Für Referenzen auf public/-Assets (Service Worker, Manifest-Icons),
    // die Next.js nicht automatisch mit dem basePath präfixt.
    NEXT_PUBLIC_BASE_PATH: basePath,
    // Der Client muss wissen, ob es überhaupt einen Server gibt.
    NEXT_PUBLIC_STATIC_EXPORT: isStaticExport ? "true" : "",
  },
  async headers() {
    if (isStaticExport) return [];
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          {
            key: "Permissions-Policy",
            // Kamera/Mikrofon/Sensoren braucht der Geräte-Check auf eigener Origin.
            value: "geolocation=(), payment=(), usb=()",
          },
        ],
      },
    ];
  },
};

export default nextConfig;
